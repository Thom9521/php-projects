# Thomas' Webshop

### Get started:
- Clone the project
- Use an apache server like XAMPP or MAMP
- Start Apache and MySQL 
- Set up the database with the table files in /DatabaseFiles

### Logins:
- Admin:
    - email: admin@admin.dk
    - password: admin123
- Register:
    - email: user@user.dk
    - password: user123
    - or sign up yourself :)